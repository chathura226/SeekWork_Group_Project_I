-----------------------------------------------------------------------------------------------------------------------
------> INFO
-----------------------------------------------------------------------------------------------------------------------

Template Name: Launch
Design/Development: templatefoundation.com
License: Free for personal and commercial use under the Creative Commons Attribution 4.0 license


-----------------------------------------------------------------------------------------------------------------------
------> CREDITS
-----------------------------------------------------------------------------------------------------------------------

- jQuery ( https://jquery.com/ )
- Bootstrap ( http://getbootstrap.com/ )
- Wagerfield Parallax ( http://matthew.wagerfield.com/parallax/ )
- Google Font Roboto ( https://fonts.google.com/specimen/Roboto )
- Font Awesome ( http://fontawesome.io/ )
- Demo Images ( https://pixabay.com/ )


-----------------------------------------------------------------------------------------------------------------------
------> NOTICE
-----------------------------------------------------------------------------------------------------------------------

- Subscribe form only works in a server environment. All subscribers will be saved in a .txt file in your servers root directory.